package corrections.weekSix;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Comparator;

import org.junit.jupiter.api.Test;

class RollNoComparatorTest {

	@Test
	void testEquals() {
		Student s1 = new Student(101, "Aerionna", "Atlanta");
		Student s2 = new Student(101, "Riah", "Jacksonville");

		Comparator comparator = new RollNoComparator();
		int result = comparator.compare(s1, s2);

		assertEquals(0, result, "Students have the same roll number");
	}

	@Test
	void testFirstGreater() {
		Student s1 = new Student(110, "Aerionna", "Atlanta");
		Student s2 = new Student(101, "Riah", "Jacksonville");

		Comparator comparator = new RollNoComparator();
		int result = comparator.compare(s1, s2);

		assertEquals(1, result, "The first student's roll number is higher than the second student's roll number.");
	}

	@Test
	void testSeconGreater() {
		Student s1 = new Student(99, "Aerionna", "Atlanta");
		Student s2 = new Student(101, "Riah", "Jacksonville");

		Comparator comparator = new RollNoComparator();
		int result = comparator.compare(s1, s2);

		assertEquals(-1, result, "The first student's roll number is lower than the second student's roll number.");
	}

}
