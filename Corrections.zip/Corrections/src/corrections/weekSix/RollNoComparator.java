package corrections.weekSix;

import java.util.Comparator;

/**
 * RollNoComparator compares two Student objects based on their roll numbers. It
 * implements the comparator interface and overrides the compare method.
 * 
 * @author Aerionna Stephenson
 */
@SuppressWarnings("rawtypes")
public class RollNoComparator implements Comparator {
	/**
	 * Compares two Student objects according to their roll number.
	 * 
	 * @param o1 the first object being compared
	 * @param o2 the second object being compared
	 * @return a negative, positive, or 0 integer based on the results of the
	 *         condition statements
	 */
	public int compare(Object o1, Object o2) {
		Student s1 = (Student) o1;
		Student s2 = (Student) o2;

		// roll numbers are the same value
		if (s1.getRollno() == s2.getRollno()) {
			return 0;
			// s1 is greater than s2
		} else if (s1.getRollno() > s2.getRollno()) {
			return 1;
			// if s1 is less than s2
		} else {
			return -1;
		}
	}
}
