package corrections.weekSix;

import java.util.ArrayList;

/**
 * The purpose of the MainTester class is to test the two comparator classes
 * (NameComparator and RollNoComparator) along with the Student class.
 * 
 * It creates an ArrayList of Student objects, adds 10 Student objects, and
 * sorts them using the selection sort algorithm, first by name, then by roll
 * number.
 * 
 * @author Aerionna Stephenson
 */

public class MainTester {
	/**
	 * The main method creates an ArrayList of Student objects and sorts them using
	 * the SelectSortAlgor class and the comparators.
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		// ArrayList is created
		ArrayList<Student> students = new ArrayList<Student>();

		// adds 10 Student Objects to the ArrayList
		students.add(new Student(1, "Billy", "124 Maplewood Ave, Newark, NJ 07102"));
		students.add(new Student(2, "Stacy", "882 Liberty Lane, Jersey City, NJ 07305"));
		students.add(new Student(3, "Kiesha", "53 Garden State Blvd, Paterson, NJ 07501"));

		students.add(new Student(4, "Lucy", "219 Hamilton Street, Trenton, NJ 08611"));

		students.add(new Student(5, "Aubrey", "341 Oceanview Drive, Atlantic City, NJ 08401"));

		students.add(new Student(6, "Taylor", "1679 Ridge Road, Edison, NJ 08817"));

		students.add(new Student(7, "Jamie", "725 Franklin Turnpike, Hackensack, NJ 07601"));

		students.add(new Student(8, "Tim", "418 Parkside Avenue, Camden, NJ 08103"));

		students.add(new Student(9, "Bob", "94 Chestnut Hill Rd, Montclair, NJ 07042"));

		students.add(new Student(10, "Joe", "302 Harbor Street, Hoboken, NJ 07030"));

		// sorts list by student name
		System.out.println("This list is sorted according to the Student's name:");
		SelectSortAlgor.selectionSort(students, new NameComparator());
		for (Student s : students) {
			System.out.println(s);
		}
		// sorts list by roll number
		System.out.println("This list is sorted according to the Student's roll number:");
		SelectSortAlgor.selectionSort(students, new RollNoComparator());
		for (Student s : students) {
			System.out.println(s);
		}

	}

}
