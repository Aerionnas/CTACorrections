package corrections.weekSix;

import java.util.Comparator;

/**
 * NameComparator compares two Student objects based on their names. It
 * implements the comparator interface and overrides the compare method.
 * 
 * @author Aerionna Stephenson
 */
@SuppressWarnings("rawtypes")
class NameComparator implements Comparator {
	/**
	 * Compares two Student objects according to their name.
	 * 
	 * @param o1 the first object being compared
	 * @param o2 the second object being compared
	 * @return a negative, positive, or 0 integer based on the values of each
	 *         String.
	 * 
	 */
	public int compare(Object o1, Object o2) {
		Student s1 = (Student) o1;
		Student s2 = (Student) o2;
		return s1.getName().compareToIgnoreCase(s2.getName());
	}
}
